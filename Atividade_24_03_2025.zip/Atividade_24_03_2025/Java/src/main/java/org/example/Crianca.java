package org.example;

public class Crianca {
    private String nome = "Artur";
    private int idade = 12;
    private double altura = 1.25;

    public void brincar() {
        System.out.println("Criança brincando no parque!");
    }

    public void comer() {
        System.out.println("Criança comendo lanche saudável");
    }

    public void estudar() {
        System.out.println("Criança estudando matemática");
    }
}

