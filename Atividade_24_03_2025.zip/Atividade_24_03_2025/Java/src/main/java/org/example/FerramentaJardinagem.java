package org.example;

public class FerramentaJardinagem {
    private String tipo = "Regar";
    private String material = "Ferro";
    private double peso = 1.25;

    public void cavar() {
        System.out.println("Cavando");
    }

    public void podar() {
        System.out.println("Podando");
    }

    public void armazenar() {
        System.out.println("Armazenando");
    }
}

