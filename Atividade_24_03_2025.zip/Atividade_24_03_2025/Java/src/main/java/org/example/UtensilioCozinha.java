package org.example;

public class UtensilioCozinha {
    private String tipo = "Panela";
    private String material  = "Aluminio";
    private String tamanho = "24";

    public void usar() {
        System.out.println("Usando Utensilio Cozinha");
    }

    public void limpar() {
        System.out.println("Utensilio Cozinha limpo");
    }

    public void guardar() {
        System.out.println("Guardado Instrumento");
    }
}