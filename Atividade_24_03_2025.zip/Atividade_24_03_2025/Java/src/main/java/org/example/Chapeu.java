package org.example;

public class Chapeu {
    private String estilo = "Antigo";
    private String cor = "Roxo";
    private int tamanho = 52;

    public void vestir() {
        System.out.println("Vestido");
    }

    public void ajustar() {
        System.out.println("Ajustando");
    }

    public void dobrar() {
        System.out.println("Dobrado");
    }
}